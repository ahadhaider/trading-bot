import time
import datetime
import os
import csv
import json
import urllib.request
import urllib.error
import self_tune

API_KEY = "AQ.Ab8RN6KjfJwKT3MzrjSBp9MZ5eK_kYbOMmZsXPQu5WQLZCw1nQ"

def query_gemini_api(prompt_text):
    # Updated to gemini-3.6-flash stable endpoint
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key={API_KEY}"
    headers = {'Content-Type': 'application/json'}
    payload = {
        "contents": [{
            "parts": [{"text": prompt_text}]
        }]
    }
    
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req) as response:
            res_data = json.loads(response.read().decode('utf-8'))
            return res_data['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
        print(f"[Gemini API Direct Call Error]: {e}")
        return None

def run_night_learning():
    print("🌙 AI Night Learning & Strategy Optimization Engine started...")
    
    while True:
        now = datetime.datetime.now()
        print(f"[{now.strftime('%H:%M:%S')}] Running Market Analysis & Night Learning...")
        
        tuning_results = self_tune.analyze_and_tune()
        
        history_summary = "No recent trades found."
        if os.path.exists("logs/trades.csv"):
            with open("logs/trades.csv", "r") as f:
                lines = f.readlines()
                if len(lines) > 1:
                    history_summary = "".join(lines[-10:])

        ai_advice = "Using standard optimization parameters."
        
        prompt = f"""
        You are an expert algorithmic trading AI. Analyze these recent trade logs and performance metrics, and provide strategic adjustments for tomorrow's market:
        Recent Trades:
        {history_summary}
        
        Performance Stats:
        {json.dumps(tuning_results)}
        
        Give concise instructions on whether to make risk tighter, adjust stop-loss, or change aggressiveness.
        """
        
        response_text = query_gemini_api(prompt)
        if response_text:
            ai_advice = response_text
            print("[AI Insight Received]: Gemini successfully analyzed market data via API!")
        else:
            print("[AI Fallback]: Using local self-tune stats.")

        strategy_summary = {
            "last_optimized": now.strftime("%Y-%m-%d %H:%M:%S"),
            "ai_status": "Active & Connected to Gemini AI",
            "tuning": tuning_results,
            "ai_recommendation": ai_advice
        }
        
        with open("night_strategy_report.json", "w") as f:
            json.dump(strategy_summary, f, indent=2)
            
        print("💡 Night AI Strategy generated & saved successfully.")
        
        time.sleep(21600)

if __name__ == "__main__":
    run_night_learning()
